# JOCA v0.3.10 — correção do pulinho na caminhada

**Estado: pronta para avaliação jogável.** Esta entrega corrige especificamente o "pulinho" vertical percebido na v0.3.9. O foco foi manter a caminhada fluida no jogo, com o corpo mais estável e sem a sensação de salto entre as passadas.

## Jogar imediatamente

1. Extraia todo o ZIP.
2. Abra `JOGAR.html`.
3. Clique na área do jogo para ativar o teclado.
4. Use **A/D** ou **←/→** para caminhar e **R** para reiniciar.

**O que observar:** caminhe continuamente e avalie se o corpo deixou de subir e descer de forma estranha. O objetivo desta versão é eliminar o pulinho sem mudar o restante do laboratório.

## O que mudou nesta versão

- Mantido o atlas de caminhada corrigido da linha v0.3.9.
- **Ajustada a ancoragem vertical no jogo** para neutralizar a oscilação do corpo durante a caminhada.
- Mantida a apresentação com transição suave apenas na emenda do ciclo 8→1.
- Controles, velocidade, câmera e cenário preservados.

## Comandos

```sh
npm run verify:art
npm run test:offline
npm run build:offline
```

A aprovação artística continua pendente do seu teste jogável.
