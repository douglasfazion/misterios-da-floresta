# Changelog — JOCA

## v0.3.10 — correção do pulinho vertical (2026-10-20)

- **Escopo:** corrigir o pequeno salto vertical percebido pelo usuário na v0.3.9.
- **Correção principal:** ajustada a ancoragem vertical de todos os quadros para priorizar estabilidade visual do corpo durante a caminhada.
- **Preservado:** atlas corrigido da v0.3.9, identidade visual do Joca, controles, velocidade, câmera e cenário.
- **Testes:** verificação do atlas, testes offline e validação no Chromium.

## v0.3.9 — caminhada refinada com atlas corrigido

- Substituição do atlas de caminhada por uma versão visualmente mais consistente.
