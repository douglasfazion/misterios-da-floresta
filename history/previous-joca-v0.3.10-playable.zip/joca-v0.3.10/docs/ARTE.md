# Arte e animação — JOCA v0.3.10

**Fonte visual jogável:** atlas em `art-source/v0.3.10-walk-generated/joca-walk.png`, copiado para `public/assets/joca-walk.png` e `dist/assets/joca-walk.png`.

- PNG RGBA 1536 × 1024; 8 poses em 4 colunas × 2 linhas; cada célula 384 × 512 px.
- A identidade do Joca permanece a mesma da linha v0.3.9.
- Nesta versão, a prioridade foi eliminar o **pulinho vertical** percebido no jogo. Para isso, todos os quadros compartilham a mesma ancoragem vertical em tempo de execução.
- A emenda 8→1 continua com uma transição curta para manter o loop suave.
