# Decisões e pendências — JOCA v0.3.10

## Implementado nesta versão

- O problema relatado foi um "pulinho" na caminhada da v0.3.9.
- A v0.3.10 corrige isso priorizando a estabilidade vertical do corpo no runtime.
- O atlas da v0.3.9 foi mantido; a mudança principal está na integração da animação ao jogo.

## Pendência

- Falta sua avaliação jogável para confirmar se o pulinho desapareceu ou se ainda há algo estranho.
