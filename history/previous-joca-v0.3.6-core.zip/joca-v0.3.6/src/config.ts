// All tunable values for this isolated, horizontal walking laboratory.
export const VERSION='0.3.6' as const;
export const WORLD={width:4200,height:720,ground:582,minX:86,maxX:4100,startX:180} as const;
export const MOVE={
 speed:210,
 response:13,              // v0.3.4 acceleration feel, exponential smoothing
 stopThreshold:0.4,        // avoid perpetual micromovement on release
 stride:168,               // world pixels per eight-pose cycle
 fixedStep:1/120,
} as const;
export const ART={
 height:300,frameWidth:384,frameHeight:512,frames:8,footY:476,anchorX:210,
 // Original PNG frames are preserved byte-for-byte from v0.3.3.
 // Each frame's opaque bottom varies; use it to keep a constant ground contact.
 frameBottoms:[471,484,479,478,468,467,470,475],idleFrame:1,
} as const;
