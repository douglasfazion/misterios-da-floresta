import {ART,WORLD} from './config';
import type {PlayerState} from './player';
/** Visual presentation only. Gait is keyed to actual traversed distance. */
export class PlayerVisual {
 private sprite:any;
 private shadow:any;
 public currentFrame:number=ART.idleFrame;
 constructor(scene:any){
  this.shadow=scene.add.ellipse(0,WORLD.ground+3,68,10,0x000000,.38);
  this.sprite=scene.add.sprite(0,WORLD.ground,'joca',ART.idleFrame)
   .setOrigin(ART.anchorX/ART.frameWidth,ART.footY/ART.frameHeight)
   .setScale(ART.height/(ART.footY-65));
 }
 update(player:PlayerState):void {
  this.sprite.setX(player.x).setFlipX(player.facing<0);
  // Each numbered frame is an independently drawn pose, not a warped static image.
  // Choose based on actual travelled distance, never on time at the world edge.
  const nextFrame=player.moving?Math.floor(player.phase*ART.frames)%ART.frames:ART.idleFrame;
  this.currentFrame=nextFrame;
  this.sprite.setFrame(nextFrame);
  // Align lowest visible foot across the v0.3.3 drawings without touching the art.
  const scale=ART.height/(ART.footY-65);
  this.sprite.setY(WORLD.ground+(ART.footY-ART.frameBottoms[nextFrame])*scale);
  this.shadow.setX(player.x);
 }
}
