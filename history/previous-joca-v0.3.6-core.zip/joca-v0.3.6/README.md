# JOCA v0.3.6 — correção da referência visual da caminhada

**Status: candidata a avaliação do jogador, não aprovada artisticamente.** Esta é uma correção da mesma iteração dedicada exclusivamente à caminhada. A v0.3.5 utilizou os desenhos errados; **as imagens certas são as da v0.3.3**, conforme esclarecimento do usuário.

## Jogar no Windows sem instalar ferramentas

1. Extraia o conteúdo do ZIP em uma pasta.
2. Abra `JOGAR.html` no Chrome ou Edge (duplo clique).
3. Clique na área do jogo para usar o teclado.
4. Ande com **A/D** ou **setas**, e pressione **R** para reiniciar.

O HTML incorpora Phaser 3.90.0, código e recursos usados no jogo. Não é necessário acessar a internet. Como alternativa, execute `INICIAR-WINDOWS.cmd` (Node.js ou Python 3) e abra `http://127.0.0.1:8000`, ou rode `node server.mjs`.

## O que foi corrigido

- Restaurado **byte a byte** `public/assets/joca-walk.png` da v0.3.3, com oito poses (4 colunas × 2 linhas, células 384 × 512); nenhuma pose foi redesenhada ou substituída.
- Os outros seis PNG/JPG de cenário reutilizados da v0.3.3 também foram conferidos e são idênticos.
- Adaptados carregamento, ancoragem e compensação de altura dos quadros para o tamanho do atlas original, sem modificar os PNGs.
- Preservadas a arquitetura TypeScript + Phaser 3.90.0 e as regras de movimentação, câmera e teclado da v0.3.5.
- Adicionado `scripts/verify-art.mjs`, para impedir regressão acidental à arte da v0.3.4.
- Interface e pacote avançados para **v0.3.6**, sem sobrescrever v0.3.5.

**Não foram incluídos** salto, ataque, novos personagens, biomas ou outras funcionalidades.

## Arquivos e execução para desenvolvimento

- `src/`: código TypeScript dividido por responsabilidades.
- `public/assets/`: arte usada na execução e no build.
- `art-source/v0.3.3-original/joca-walk.png`: cópia de referência original, sem alterações.
- `dist/`: versão Web compilada que pode ser servida por HTTP.
- `JOGAR.html`: mesma versão para abertura local, independente de servidor.
- `tests/`: regressão de regras e cenários E2E, conforme dependências disponíveis.
- `history/`: versões anteriores preservadas (não consideradas artisticamente aprovadas).

Com Node.js e npm, quando a instalação das dependências estiver disponível:

```sh
npm ci
npm run dev
npm run test
npm run build
npm run test:e2e
```

Com Node.js e TypeScript (`tsc` instalado), sem npm disponível:

```sh
npm run verify:art    # confere SHA-256, dimensões e formato da arte original
npm run test:offline  # 11 testes de regras com node:test
npm run build:offline # TypeScript AMD + dist + JOGAR.html
```

## O que ainda precisa ser aprovado

Abra o jogo e examine o ciclo completo nos dois sentidos, a transição entre parado e caminhando, a estabilidade dos pés e a sensação de controle. **A validação automatizada não garante qualidade estética ou naturalidade perfeita**: continuaremos ajustando esta mesma iteração se necessário. Não produzimos quadros inéditos nem afirmamos que o ciclo desenhado pela v0.3.3 resolve toda a biomecânica.

Veja `docs/CHANGELOG.md`, `docs/QA.md`, `docs/ARTE.md` e `docs/DECISOES.md`.
