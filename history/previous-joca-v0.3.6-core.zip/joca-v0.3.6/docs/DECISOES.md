# Decisões e pendências — JOCA v0.3.6

## Aprovado pelo usuário

- Desenvolvimento real e incremental, com correção de iterações reprovadas antes da expansão.
- TypeScript + Phaser, sem mudar tecnologia silenciosamente.
- Caminhada como única funcionalidade a validar agora.
- **Usar as imagens da v0.3.3 como identidade visual correta de Joca** (esclarecimento posterior à v0.3.5).
- Entrega exclusivamente em ZIP versionado.

## Preservação

- Código da v0.3.5 é a base para regras de movimento, câmera, teclado e organização.
- Atlas v0.3.3 é a fonte visual sem edição de pixels.
- Phaser 3.90.0 permanece como no projeto existente.
- ZIPs antigos mantidos em `history/` para recuperação; **não** implica aprovação artística de versões passadas.

## Escopo excluído

Sem novos biomas, física vertical, salto, combate, bosses ou refatoração integral. Cenário continua provisório para validar caminhada.

## Pendência

Avaliação do usuário quanto à alternância de pernas, chão, proporções, cadência, postura e transições dentro do jogo. Qualquer correção seguinte continua no escopo de caminhada.
