# QA — JOCA v0.3.6

## Executado nesta entrega

- `node scripts/verify-art.mjs`: confirma SHA-256 idêntico entre arte original de v0.3.3 e spritesheet servido; PNG 1536×1024 (8 quadros 384×512).
- Comparação de todos os arquivos PNG e JPG reutilizados da v0.3.3: **7/7 idênticos** ao ZIP antigo.
- `node scripts/test-offline.mjs`: **11/11** testes de lógica com `node:test` passaram.
- `node scripts/build-offline.mjs`: TypeScript compilado, `dist/` e `JOGAR.html` gerados sem downloads.
- Chromium headless com a mesma página standalone injetada via `page.set_content`: **13/13** verificações passaram; Phaser carregado, atlas pronto, caminhada bilateral, >=6 quadros distintos, câmera, parada, reset, blur e sem erros JavaScript.

## Ainda não executado e não garantido

- Instalação e suíte oficial do npm/Vitest/Playwright não puderam ser executadas aqui por indisponibilidade de dependências locais e acesso npm. O teste Chromium foi realizado diretamente pelo Python Playwright instalado no ambiente, e não pela suíte npm.
- Abrir `file://` diretamente ou navegar via HTTP no Chromium de automação foi bloqueado por política local. O teste usou o HTML standalone integral numa página `about:blank`, não substituindo a validação local pelo usuário.
- A qualidade estética da caminhada, o contato do pé, a mudança de peso e a sensação dos controles **dependem da avaliação do usuário**.
