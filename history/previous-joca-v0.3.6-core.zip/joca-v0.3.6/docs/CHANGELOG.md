# Histórico de versões

## v0.3.6 — 20/10/2026 — correção visual (aguardando avaliação)

- Corrigida a origem dos desenhos de Joca: **usar v0.3.3**, nunca os quadros de v0.3.4 na caminhada aprovada para teste.
- Restaurado atlas original de oito poses, com exatamente os mesmos bytes da v0.3.3 (SHA-256 conferível por script).
- Adaptadas as dimensões dos quadros e a ancoragem vertical; adicionada compensação leve por quadro na posição do pé, sem modificar a imagem.
- Mantidas regras e comportamentos de movimento e câmera da v0.3.5; versão de UI, documentação e teste atualizadas.
- Sem novas mecânicas nem alteração de stack; anterior preservada em `history/`.

**Limitação:** desenhos originais da v0.3.3 têm limites próprios para uma caminhada perfeitamente natural. Testes de software não equivalem à aprovação visual. Este pacote ainda não está aprovado artisticamente.

## v0.3.5 — 20/10/2026 — referência de arte incorreta

- Restaurada a arquitetura Phaser + TypeScript, testes e build independente.
- Melhorados suavização, passo fixo, virar, foco e reprodução por distância percorrida.
- **Problema apontado pelo usuário:** utilizada arte de Joca da v0.3.4, em vez da referência certa da v0.3.3.
