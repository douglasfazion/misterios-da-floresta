# JOCA v0.3.6 — referência visual correta

**Referência aprovada para os desenhos: v0.3.3** (informada explicitamente após a entrega v0.3.5).

- Fonte recuperada: ZIP `joca-v0.3.3-web.zip`, `public/assets/joca-walk.png`.
- Cópia literal, sem processamento: `art-source/v0.3.3-original/joca-walk.png`.
- Arquivo usado pelo jogo: `public/assets/joca-walk.png`. Ambos são byte a byte idênticos (verifique com `npm run verify:art`).
- Atlas PNG RGBA, 1536×1024, organizado em 4×2. Cada célula tem 384×512 px.
- O corpo semi-humano e lupino, vestimentas, pelagem, cauda, cabelos, detalhes dourados e faixas vermelhas são preservados sem retoque ou novo desenho.
- A lógica define âncora central em x=210, referência vertical em y=476 e acompanha a parte inferior de cada quadro `[471,484,479,478,468,467,470,475]` para apoiar os pés na linha do chão sem alterar a imagem.
- A escala visual é parametrizada em `src/config.ts`. O retorno ao repouso usa a segunda pose (índice 1). Os oito quadros avançam pelo deslocamento real, não por uma animação estática deformada.

**Atenção:** A normalização de apoio evita diferenças de posição vertical decorrentes dos recortes originais, mas não corrige por si só inconsistências de anatomia, perspectiva ou distribuição de peso entre os desenhos. Qualidade da caminhada deve ser julgada dentro do jogo.
