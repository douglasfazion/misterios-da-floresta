# JOCA v0.3.4 — Caminhada do Joca parcialmente humano

## Como testar
Extraia todo o ZIP para uma pasta e abra index.html no Chrome, Edge ou Firefox. Não abra o HTML dentro do ZIP. Não precisa instalar nada nem ter internet.

A / D ou setas: caminhar. R: voltar ao início.

## Alterações desde v0.3.2
- Integrados os 8 quadros do estudo v0.3.3, com rosto humano, cauda, garras, faixa vermelha e amuletos.
- Mantidos o cenário, a câmera e a aceleração da versão anterior.
- Ciclo sincronizado com a distância percorrida (168 pixels por ciclo).
- Pés alinhados à linha do chão; espelhamento em torno do corpo ao virar.
- Animação não avança quando o personagem chega ao limite do cenário.
- Quadros recortados novamente da imagem original e verificados.

## Limitações conhecidas
Estudo visual experimental: os desenhos ainda variam em postura, anatomia e acessórios entre quadros. A integração permite avaliar o resultado no cenário; não significa que a fluidez esteja aprovada. Parado usa o primeiro quadro da caminhada. Corrida, salto, ataque e inimigos continuam desativados nesta versão focada em caminhada.
