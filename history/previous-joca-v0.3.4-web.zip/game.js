'use strict';
const canvas=document.getElementById('game');const ctx=canvas.getContext('2d');canvas.width=1280;canvas.height=720;
const W=1280,H=720,GROUND=582,WORLD=4200;
const assets={};let ready=0,failed=0;const names=[...Array.from({length:8},(_,i)=>`joca_walk_${String(i).padStart(2,'0')}`),'bg_forest','bg_ruins','bg_waterfall','distant_forest','stone','moss'];
for(const name of names){const im=new Image();assets[name]=im;im.onload=()=>ready++;im.onerror=()=>{failed++;};im.src=`assets/${name}.${name.startsWith('bg_')||name==='distant_forest'?'jpg':'png'}`}
const keys=new Set();window.addEventListener('keydown',e=>{if(['KeyA','KeyD','ArrowLeft','ArrowRight','KeyR'].includes(e.code))e.preventDefault();keys.add(e.code);if(e.code==='KeyR')reset()});window.addEventListener('keyup',e=>keys.delete(e.code));window.addEventListener('blur',()=>keys.clear());
let p,cam,last=0;function reset(){p={x:180,vx:0,phase:0,face:1,distance:0};cam=0;}reset();
function img(name,x,y,w,h,alpha=1,flip=false){let a=assets[name];if(!a||!a.complete||!a.naturalWidth)return;ctx.save();ctx.globalAlpha=alpha;if(flip){ctx.translate(2*x+w,0);ctx.scale(-1,1)}ctx.drawImage(a,x,y,w,h);ctx.restore()}
function step(dt){const dir=(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0);if(dir)p.face=dir;
const target=dir*210,blend=1-Math.exp(-dt*13);p.vx+=(target-p.vx)*blend;
if(Math.abs(p.vx)<0.4&&!dir)p.vx=0;
const oldX=p.x;
p.x=Math.max(86,Math.min(WORLD-100,p.x+p.vx*dt));
const movement=Math.abs(p.x-oldX);
p.moving=movement>.001;
// One full gait every ~168 world units. Phase advances by distance, never by arbitrary frame timing.
if(movement>.001){p.distance+=movement;p.phase=(p.phase+movement/168*8)%8;}
cam+=(Math.max(0,Math.min(WORLD-W,p.x-480))-cam)*(1-Math.exp(-dt*4.5));}
function background(){ctx.fillStyle='#071019';ctx.fillRect(0,0,W,H);img('distant_forest',-cam*.032,0,1480,720,.45);for(const [j,n] of ['bg_forest','bg_ruins','bg_waterfall'].entries()){const widths=[600,700,790],h=[710,640,580],factor=[.07,.17,.30];let sw=widths[j],offset=-((cam*factor[j])%sw);for(let x=offset-sw;x<W+sw;x+=sw)img(n,x,50+j*32,sw,h[j],[.40,.43,.68][j]);}ctx.fillStyle='#07121a44';ctx.fillRect(0,0,W,H);}
function floor(){ctx.save();ctx.translate(-cam,0);ctx.fillStyle='#192421';ctx.fillRect(0,GROUND,WORLD,200);for(let x=0;x<WORLD;x+=80){img('stone',x,GROUND+14,82,120,.78);img('moss',x,GROUND-15,89,28,.92)}ctx.fillStyle='#7e966e';ctx.globalAlpha=.58;ctx.fillRect(0,GROUND,WORLD,3);ctx.restore()}
function joca(){const x=p.x-cam,feet=GROUND;
ctx.save();ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(x,feet+3,35,6,0,0,Math.PI*2);ctx.fill();ctx.restore();
const active=p.moving && Math.abs(p.vx)>.8;
const frame=active?Math.floor(p.phase)%8:0;
const name=`joca_walk_${String(frame).padStart(2,'0')}`;
const scale=.5;
ctx.save();ctx.translate(x,feet);ctx.scale(p.face*scale,scale);
img(name,-300,-450,540,500);ctx.restore();
return active?`CAMINHANDO · quadro ${frame+1}/8`:'PARADO'}
function overlay(state){ctx.fillStyle='#02080bcb';ctx.fillRect(17,17,540,88);ctx.strokeStyle='#8c7557';ctx.lineWidth=1.5;ctx.strokeRect(17,17,540,88);ctx.font='bold 21px Georgia';ctx.fillStyle='#f1d4ad';ctx.fillText('JOCA  ·  LABORATÓRIO DE CAMINHADA v0.3.4',30,47);ctx.font='16px Georgia';ctx.fillStyle='#c6d6d0';ctx.fillText(`${state}  •  ${Math.abs(p.vx).toFixed(0)} px/s`,30,75);ctx.font='14px Georgia';ctx.fillStyle='#dec8a7';ctx.fillText(`A / D ou ← / →: caminhar     •     R: reiniciar`,30,95);if(failed){ctx.fillStyle='#ffb29a';ctx.fillText(`${failed} imagens não carregadas`,600,55)}}
function draw(){background();floor();const state=joca();overlay(state)}
function loop(ms){if(ready+failed<names.length){ctx.fillStyle="#071019";ctx.fillRect(0,0,W,H);ctx.fillStyle="#f1d4ad";ctx.font="24px Georgia";ctx.fillText("Carregando JOCA v0.3.4…",440,360);requestAnimationFrame(loop);return;}if(!last)last=ms;let dt=Math.min(.05,(ms-last)/1000);last=ms;step(dt);draw();requestAnimationFrame(loop)}requestAnimationFrame(loop);
