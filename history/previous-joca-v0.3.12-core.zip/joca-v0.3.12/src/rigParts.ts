/* Cutting coordinates and joint pivots from the approved v0.3.3 original. */
export const RIG_PARTS={
 "tail": {
  "pivot": [
   145,
   28
  ],
  "at": [
   170,
   333
  ],
  "bounds": [
   25,
   305,
   159,
   104
  ]
 },
 "rear_upper_arm": {
  "pivot": [
   49,
   27
  ],
  "at": [
   185,
   188
  ],
  "bounds": [
   136,
   161,
   82,
   106
  ],
  "end": [
   153,
   247
  ]
 },
 "rear_forearm": {
  "pivot": [
   42,
   12
  ],
  "at": [
   153,
   247
  ],
  "bounds": [
   111,
   235,
   72,
   100
  ],
  "end": [
   143,
   306
  ]
 },
 "near_upper_arm": {
  "pivot": [
   26,
   19
  ],
  "at": [
   244,
   203
  ],
  "bounds": [
   218,
   184,
   60,
   95
  ],
  "end": [
   262,
   258
  ]
 },
 "near_forearm": {
  "pivot": [
   18,
   17
  ],
  "at": [
   262,
   258
  ],
  "bounds": [
   244,
   241,
   74,
   87
  ],
  "end": [
   296,
   308
  ]
 },
 "rear_thigh": {
  "pivot": [
   65,
   19
  ],
  "at": [
   180,
   301
  ],
  "bounds": [
   115,
   282,
   101,
   130
  ],
  "end": [
   141,
   371
  ]
 },
 "rear_calf": {
  "pivot": [
   46,
   18
  ],
  "at": [
   141,
   371
  ],
  "bounds": [
   95,
   353,
   70,
   94
  ],
  "end": [
   127,
   426
  ]
 },
 "rear_foot": {
  "pivot": [
   39,
   18
  ],
  "at": [
   127,
   426
  ],
  "bounds": [
   88,
   408,
   88,
   63
  ]
 },
 "near_thigh": {
  "pivot": [
   21,
   26
  ],
  "at": [
   226,
   305
  ],
  "bounds": [
   205,
   279,
   79,
   134
  ],
  "end": [
   261,
   376
  ]
 },
 "near_calf": {
  "pivot": [
   25,
   22
  ],
  "at": [
   261,
   376
  ],
  "bounds": [
   236,
   354,
   71,
   101
  ],
  "end": [
   280,
   422
  ]
 },
 "near_foot": {
  "pivot": [
   41,
   14
  ],
  "at": [
   280,
   422
  ],
  "bounds": [
   239,
   408,
   101,
   65
  ]
 },
 "torso": {
  "pivot": [
   57,
   200
  ],
  "at": [
   210,
   300
  ],
  "bounds": [
   153,
   100,
   144,
   199
  ]
 },
 "cloth": {
  "pivot": [
   86,
   61
  ],
  "at": [
   211,
   280
  ],
  "bounds": [
   125,
   219,
   173,
   175
  ]
 }
} as const;
export type RigPartName=keyof typeof RIG_PARTS;
export const RIG_NAMES=Object.keys(RIG_PARTS) as RigPartName[];
