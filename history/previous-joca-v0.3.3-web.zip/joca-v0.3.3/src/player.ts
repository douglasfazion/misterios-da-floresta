import {MOVE,WORLD} from './config';
export type Direction=-1|0|1;
export interface PlayerState {x:number;velocity:number;facing:-1|1;phase:number;distance:number;moving:boolean}
export function createPlayer():PlayerState{return {x:WORLD.startX,velocity:0,facing:1,phase:0,distance:0,moving:false};}
function approach(value:number,target:number,amount:number){return value<target?Math.min(target,value+amount):Math.max(target,value-amount);}
export function stepPlayer(state:PlayerState,direction:Direction,dt:number):PlayerState{
 if(!Number.isFinite(dt)||dt<=0)return state;
 const target=direction*MOVE.speed;
 const velocity=approach(state.velocity,target,(direction?MOVE.acceleration:MOVE.deceleration)*dt);
 const x=Math.max(WORLD.minX,Math.min(WORLD.maxX,state.x+velocity*dt));
 const delta=x-state.x;
 const distance=Math.abs(delta);
 const blocked=(x===WORLD.minX&&velocity<0)||(x===WORLD.maxX&&velocity>0);
 return {x,velocity:blocked?0:velocity,facing:delta>0?1:delta<0?-1:state.facing,
 phase:(state.phase+distance/MOVE.stride)%1,distance:state.distance+distance,moving:distance>0.00001};
}
export function stopPlayer(state:PlayerState):PlayerState{return {...state,velocity:0,moving:false};}
