import Phaser from 'phaser';
import {WORLD} from './config';
export function updateCamera(camera:Phaser.Cameras.Scene2D.Camera,x:number,dt:number){
 const target=Phaser.Math.Clamp(x-480,0,WORLD.width-1280);
 camera.scrollX+=(target-camera.scrollX)*(1-Math.exp(-5*dt));
}
