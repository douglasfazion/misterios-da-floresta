import Phaser from 'phaser';
function asset(name:string){
 const embedded=(window as unknown as {__JOCA_ASSETS__?:Record<string,string>}).__JOCA_ASSETS__;
 return embedded?.[name]??`assets/${name}`;
}
export function loadAssets(scene:Phaser.Scene){
 for(const name of ['bg_waterfall'])scene.load.image(name,asset(`${name}.jpg`));
 for(const name of ['stone','moss'])scene.load.image(name,asset(`${name}.png`));
 scene.load.spritesheet('joca',asset('joca-walk.png'),{frameWidth:384,frameHeight:512});
}
