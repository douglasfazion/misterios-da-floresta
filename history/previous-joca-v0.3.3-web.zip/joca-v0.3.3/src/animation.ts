import Phaser from 'phaser';
import {ART,WORLD} from './config';
import type {PlayerState} from './player';
export class PlayerVisual{
 private sprite:Phaser.GameObjects.Sprite;
 private shadow:Phaser.GameObjects.Ellipse;
 constructor(scene:Phaser.Scene){
 this.shadow=scene.add.ellipse(0,WORLD.ground+2,65,10,0x000000,.35);
 this.sprite=scene.add.sprite(0,WORLD.ground,'joca',0).setOrigin(ART.anchorX/ART.frameWidth,ART.footY/ART.frameHeight).setScale(ART.height/ART.footY);
 }
 update(player:PlayerState){
 this.sprite.setX(player.x).setFlipX(player.facing<0);
 // Distance drives playback; no tweening or deformation of a static image.
 this.sprite.setFrame(player.moving?Math.floor(player.phase*ART.frames):0);
 this.shadow.setX(player.x);
 }
}
