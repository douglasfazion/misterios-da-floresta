export const VERSION='0.3.3';
export const WORLD={width:2400,height:720,ground:582,minX:110,maxX:2290,startX:300};
export const MOVE={speed:150,acceleration:950,deceleration:1250,stride:144,fixedStep:1/120};
export const ART={height:300,frameWidth:384,frameHeight:512,frames:8,footY:460,anchorX:210};
