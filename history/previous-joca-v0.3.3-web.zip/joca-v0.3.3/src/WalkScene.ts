import Phaser from 'phaser';
import {MOVE} from './config';
import {createPlayer,stepPlayer,stopPlayer} from './player';
import {InputController} from './input';
import {loadAssets} from './assets';
import {createEnvironment} from './environment';
import {PlayerVisual} from './animation';
import {updateCamera} from './camera';
export class WalkScene extends Phaser.Scene{
 private player=createPlayer();private inputController!:InputController;private visual!:PlayerVisual;
 private accumulator=0;private failed=false;private ready=false;
 constructor(){super('walk');}
 preload(){this.load.on('loaderror',()=>{this.failed=true;document.querySelector('#status')!.textContent='Erro ao carregar assets. Recarregue pelo servidor local.';});loadAssets(this);}
 create(){if(this.failed)return;
 createEnvironment(this);this.visual=new PlayerVisual(this);this.visual.update(this.player);
 this.inputController=new InputController(document.querySelector('#game')!,()=>this.reset(),()=>{this.player=stopPlayer(this.player);this.accumulator=0;});
 const button=document.querySelector('#reset')!;const reset=()=>{this.reset();(document.querySelector('#game') as HTMLElement).focus();};button.addEventListener('click',reset);
 this.events.once('shutdown',()=>{this.inputController.destroy();button.removeEventListener('click',reset);});
 this.ready=true;
 if(new URLSearchParams(location.search).has('test')){Object.assign(window,{__JOCA__:{snapshot:()=>({...this.player,cameraX:this.cameras.main.scrollX,ready:this.ready}),reset:()=>this.reset()}});}
 }
 private reset(){this.player=createPlayer();this.accumulator=0;this.cameras.main.scrollX=0;}
 update(_time:number,delta:number){if(!this.ready)return;
 this.accumulator+=Math.min(delta/1000,.1);
 while(this.accumulator>=MOVE.fixedStep){this.player=stepPlayer(this.player,this.inputController.direction(),MOVE.fixedStep);this.accumulator-=MOVE.fixedStep;}
 this.visual.update(this.player);updateCamera(this.cameras.main,this.player.x,Math.min(delta/1000,.1));
 document.querySelector('#status')!.textContent=`${this.player.moving?'Caminhando':'Parado'} · ${Math.round(Math.abs(this.player.velocity))} px/s`;
 }
}
