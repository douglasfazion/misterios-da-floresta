import {test,expect} from '@playwright/test';
const snapshot=async(page:any)=>page.evaluate(()=> (window as any).__JOCA__.snapshot());
test.beforeEach(async({page})=>{await page.goto('/?test');await page.waitForFunction(()=> (window as any).__JOCA__?.snapshot().ready);await page.locator('#game').click();});
test('loads assets, walks, releases, reverses and resets',async({page})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
 const initial=await snapshot(page);await page.keyboard.down('KeyD');
 await expect.poll(async()=> (await snapshot(page)).x).toBeGreaterThan(initial.x+100);
 await page.keyboard.up('KeyD');await expect.poll(async()=> (await snapshot(page)).velocity).toBe(0);
 const stopped=await snapshot(page);await page.waitForTimeout(150);expect((await snapshot(page)).x).toBe(stopped.x);
 await page.keyboard.down('ArrowLeft');await expect.poll(async()=> (await snapshot(page)).x).toBeLessThan(stopped.x-40);await page.keyboard.up('ArrowLeft');
 await page.keyboard.press('KeyR');await expect.poll(async()=> (await snapshot(page)).x).toBe(300);
 expect((await snapshot(page)).cameraX).toBe(0);expect(errors).toEqual([]);
});
test('blur releases held keys and returning does not resume walking',async({page})=>{
 await page.keyboard.down('KeyD');await expect.poll(async()=> (await snapshot(page)).velocity).toBe(150);
 await page.evaluate(()=>window.dispatchEvent(new Event('blur')));await expect.poll(async()=> (await snapshot(page)).velocity).toBe(0);
 const x=(await snapshot(page)).x;await page.keyboard.up('KeyD');await page.locator('#game').click();await page.waitForTimeout(200);expect((await snapshot(page)).x).toBe(x);
});
test('camera follows and reset button restores position',async({page})=>{
 await page.keyboard.down('KeyD');await expect.poll(async()=> (await snapshot(page)).cameraX,{timeout:6000}).toBeGreaterThan(30);await page.keyboard.up('KeyD');
 await page.locator('#reset').click();expect((await snapshot(page)).x).toBe(300);expect((await snapshot(page)).cameraX).toBe(0);
});
