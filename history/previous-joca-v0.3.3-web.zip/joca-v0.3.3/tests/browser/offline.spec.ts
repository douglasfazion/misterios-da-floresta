import {test,expect} from '@playwright/test';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
test('ZIP opens directly as a local file without a server or network',async({page})=>{
 const errors:string[]=[];const requests:string[]=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url())});
 await page.goto(pathToFileURL(resolve('JOGAR.html')).href+'?test');
 await page.waitForFunction(()=> (window as any).__JOCA__?.snapshot().ready);
 await page.locator('#game').click();await page.keyboard.down('KeyD');
 await expect.poll(()=>page.evaluate(()=> (window as any).__JOCA__.snapshot().x)).toBeGreaterThan(350);
 await page.keyboard.up('KeyD');await expect.poll(()=>page.evaluate(()=> (window as any).__JOCA__.snapshot().velocity)).toBe(0);
 expect(errors).toEqual([]);expect(requests).toEqual([]);
});
