import {describe,it,expect} from 'vitest';
import {createPlayer,stepPlayer,stopPlayer, type PlayerState, type Direction} from '../src/player';
import {MOVE,WORLD} from '../src/config';
function advance(state:PlayerState,dir:Direction,seconds:number){for(let i=0;i<Math.round(seconds/MOVE.fixedStep);i++)state=stepPlayer(state,dir,MOVE.fixedStep);return state;}
describe('movement contract',()=>{
 it('walks at capped speed in either direction',()=>{for(const direction of [-1,1] as const){const p=advance({...createPlayer(),x:1200},direction,1);expect(p.velocity).toBe(direction*MOVE.speed);expect(p.facing).toBe(direction);expect((p.x-1200)*direction).toBeGreaterThan(100);}});
 it('stops without drift after releasing',()=>{let p=advance(createPlayer(),1,1);p=advance(p,0,.3);const x=p.x;expect(p.velocity).toBe(0);expect(advance(p,0,1).x).toBe(x);});
 it('changes facing only when displacement changes direction',()=>{let p=advance(createPlayer(),1,1);p=stepPlayer(p,-1,MOVE.fixedStep);expect(p.facing).toBe(1);p=advance(p,-1,.5);expect(p.facing).toBe(-1);expect(p.velocity).toBe(-MOVE.speed);});
 it('never crosses either boundary and stops phase at a wall',()=>{for(const direction of [-1,1] as const){let p=advance(createPlayer(),direction,30);expect(p.x).toBe(direction===1?WORLD.maxX:WORLD.minX);expect(p.velocity).toBe(0);expect(p.moving).toBe(false);const next=advance(p,direction,1);expect(next.phase).toBe(p.phase);expect(next.distance).toBe(p.distance);expect(advance(p,direction===1?-1:1,.5).x).not.toBe(p.x);}});
 it('gait counts real displacement including a partial final step',()=>{const p=stepPlayer({...createPlayer(),x:WORLD.maxX-1,velocity:150},1,1/60);expect(p.distance).toBe(1);expect(p.phase).toBeCloseTo(1/MOVE.stride);});
 it('clears velocity immediately when focus is lost',()=>{expect(stopPlayer(advance(createPlayer(),1,1)).velocity).toBe(0);});
 it('reset has stable initial state',()=>{expect(createPlayer()).toEqual({x:300,velocity:0,facing:1,phase:0,distance:0,moving:false});});
 it('ignores invalid time steps',()=>{const p=createPlayer();for(const dt of [-1,0,NaN,Infinity])expect(stepPlayer(p,1,dt)).toEqual(p);});
});
