# JOCA v0.3.3 — Laboratório de caminhada

Entrega candidata para avaliação. Escopo: corrigir caminhada; sem salto, ataque, inimigos ou expansão do mapa.

## Jogar — sem instalação

1. Extraia TODO o ZIP.
2. Abra `JOGAR.html` no Chrome ou Edge do computador.
3. Clique na área do jogo para ativar o teclado.
4. A/D ou setas: caminhar. R ou botão: reiniciar.

`JOGAR.html` contém o build compilado e os assets incorporados. Não usa CDN nem conexão externa. O código-fonte continua separado em `src/`; esse HTML é somente um formato de distribuição gerado automaticamente.

Se o navegador bloquear arquivos locais: use `INICIAR-WINDOWS.cmd` (requer Node.js ou Python 3) ou execute `node server.mjs`, abrindo http://127.0.0.1:8000. Mantenha o terminal aberto. Se a página abrir antes de o servidor iniciar, atualize-a. Esse servidor aceita apenas conexões do próprio computador.

## Desenvolvimento

Node.js 22.12+ (recomendado Node 24) e npm.

```
npm ci
npm run dev
npm test
npm run build
npx playwright install chromium
npm run test:e2e
```

`npm run build` verifica TypeScript, gera `dist/` e recria `JOGAR.html`.
`npm run check` executa os testes unitários, build e testes de navegador.
`npm run preview` serve o build convencional. Testes de navegador usam Chromium.

## Organização

- `src/config.ts`: versão, escala e parâmetros.
- `src/player.ts`: regras de movimento independentes da engine.
- `src/input.ts`: teclado, foco e liberação das teclas.
- `src/WalkScene.ts`: integração e passo fixo de 120 Hz.
- `src/animation.ts`: apresentação do personagem, sem deformar sprites.
- `src/camera.ts`: acompanhamento e limites.
- `src/environment.ts`: montagem provisória do ambiente.
- `src/assets.ts`: carregamento, inclusive build independente.
- `src/main.ts` e `src/style.css`: inicialização e interface.
- `public/assets/`: imagens usadas pelo projeto.
- `tests/`: regras isoladas e fluxos reais de navegador.
- `scripts/standalone.mjs`: empacotamento do HTML independente.
- `art-source/`: spritesheet gerada antes do alinhamento técnico.
- `history/`: ZIP v0.3.2 preservado, sem pressupor sua aprovação.

## O que avaliar

Caminhe nos dois sentidos; solte as teclas; inverta a direção durante o movimento; alcance os extremos; troque de janela e volte; reinicie.
Observe especialmente anatomia, apoio dos pés, ritmo e transições. Informe se a caminhada é aprovada ou qual defeito precisa de correção. A próxima iteração não está autorizada automaticamente.

Veja `docs/CHANGELOG.md`, `docs/DECISOES.md` e `docs/QA.md`.
