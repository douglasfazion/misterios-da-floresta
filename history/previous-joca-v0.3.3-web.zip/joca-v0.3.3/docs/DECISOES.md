# Registro breve

## Aprovado pelo usuário nesta conversa

- Desenvolvimento incremental; aprovação antes de cada novo escopo.
- Somente ZIP versionado, sem publicar link ou Site.
- TypeScript + Phaser, Vite, Vitest e Playwright.
- v0.3.3 focada em corrigir a caminhada antes de ampliar o jogo.
- Preservar a identidade de Joca parcialmente humano e lupino.

## Implementação desta candidata

- Phaser 3.90.0: API usada e testada neste pacote; sem migração silenciosa para outra versão principal.
- Sem engine física nesta etapa horizontal. O controlador lógico tem passo fixo e limites próprios.
- Dimensões lógicas 1280×720; mundo de teste 2400 px; chão y=582.
- Movimento máximo 150 px/s; ciclo a cada 144 px efetivos. Valores centralizados para ajuste.
- Referência visual utilizada: imagem `8b4bc20a-ac07-4f68-b698-993a2dbd7373(1).png`, disponível no histórico do projeto, e prancha conceitual de JOCA.
- Fontes de arte de cenário: ZIP fornecido v0.3.2. Nenhum novo bioma ou decisão narrativa introduzido.
- A v0.3.2 fica preservada como histórico, não como versão aprovada.

## Pendente

- Avaliação do usuário sobre o desenho, a caminhada integrada e a sensação dos controles.
- Se reprovada: corrigir a mesma iteração e registrar a correção.
- Depois de aprovada: propor escopo para exploração em um pequeno recorte interconectado; definir grade e escala do tileset antes de produzir cenário novo.
