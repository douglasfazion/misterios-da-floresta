# QA — JOCA v0.3.3

## Executado

- TypeScript: verificação passou.
- Build Vite + geração do HTML independente: passaram.
- Vitest: 8 testes passaram (movimento bidirecional, parada, inversão, limites, distância real, perda de foco, reinício e tempo inválido).
- Playwright: 4 testes passaram na execução final isolada, usando Chromium 153 headless neste ambiente.
  - Abertura direta de JOGAR.html via file://, caminhada e parada sem requisições HTTP.
  - Carregamento, caminhar, soltar, inverter e reiniciar.
  - Perda de foco limpa movimento e retorno não retoma tecla presa.
  - Câmera acompanha e botão reiniciar restaura posição.
- Verificação adicional no navegador: extremo direito x=2290, velocidade zero, fase da caminhada estável ao insistir contra limite; nenhuma falha de página ou resposta HTTP registrada.
- Inspeção visual de capturas do jogo em repouso e ao longo da caminhada; personagem renderizado com transparência e cenário integrado.

Uma execução de câmera falhou durante outra sessão de inspeção concorrente. A suíte completa passou ao rodar isoladamente, sem mudar a expectativa nem o código do teste. Possível interferência de foco/carga; manter esse teste nas próximas regressões.

O download padrão de Chromium pelo Playwright falhou neste ambiente. Foi usado um executável Chromium 153 obtido pelo pacote de QA @sparticuz/chromium, somente na máquina de teste, informado pela variável JOCA_CHROMIUM_PATH. Esse pacote e binário não são dependências do jogo nem estão no ZIP. O comando normal de testes usa o Chromium instalado pelo próprio Playwright.

## Ainda depende do usuário

- Aprovação da fluidez, fidelidade artística, apoio dos pés e sensação dos controles.
- Execução no Windows e navegador do usuário; testes aqui ocorreram em Linux/Chromium.
- Meta de desempenho não certificada em hardware real; não há promessa de FPS nesta candidata.

Esta entrega é candidata de teste, não aprovação automática da animação.
