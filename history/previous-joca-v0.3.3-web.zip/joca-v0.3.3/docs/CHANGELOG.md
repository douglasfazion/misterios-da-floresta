# v0.3.3 — candidata à avaliação

- Migração do laboratório Canvas para TypeScript + Phaser 3.90.0, com módulos separados.
- Vite 8.3.4, Vitest 5.0.5 e Playwright 1.64.1 fixados no lockfile.
- Nova sequência de oito poses desenhadas, com transparência e alinhamento técnico. Não reutiliza a reconstrução das pernas da v0.3.2.
- Animação avança pelo deslocamento real; para de avançar nos limites.
- Atualização lógica com passo fixo, aceleração e desaceleração ajustáveis.
- Câmera, reinício e limpeza de entrada ao perder foco.
- Interface com versão e estado de avaliação.
- Build independente `JOGAR.html`, build convencional `dist/`, fontes e testes.

## Limitações

- Caminhada é uma proposta visual para avaliação, não animação final aprovada. Oito quadros têm variações de desenho; contato dos pés e transições podem precisar de refinamento após o teste do usuário.
- Repouso usa uma pose do ciclo, sem animação própria de respiração. Ao parar, muda para essa pose.
- O personagem vira por espelhamento horizontal, sem animação de giro.
- Deslocamento horizontal sobre um piso fixo; não há física vertical nem colisões com plataformas. Os limites horizontais são lógicos e independentes da arte.
- Ambiente provisório reaproveita imagens e peças da v0.3.2. Repetição de fundo foi espelhada para reduzir cortes. Ainda não é um tileset final nem a seção interconectada.
- Som, celular, controle físico e outros navegadores não estão cobertos nesta entrega.
- Testes funcionais não demonstram, sozinhos, fluidez artística ou desempenho no computador do usuário.
