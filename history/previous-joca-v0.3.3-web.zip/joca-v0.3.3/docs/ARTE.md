# Preparação visual

Modo: geração/edição pela ferramenta integrada de imagens, usando a imagem de referência do projeto. Não foi usado fallback de API.

Arquivos: `art-source/joca-walk-generated.png` é a saída gerada. `public/assets/joca-walk.png` é o atlas preparado, também copiado para `dist/assets/`. O build independente incorpora esse mesmo atlas.

Brief: oito poses de caminhada em 4 colunas × 2 linhas, personagem voltado para a direita, estilo 2D desenhado. Preservar rosto humano, cabelo preto, orelhas pontudas, torso humano, pelos nos ombros e antebraços, calças rasgadas, faixa vermelha, adornos de bronze, cauda e garras. Alternar contato, descida, passagem e elevação das pernas; braços opostos às pernas; sem deformação de uma imagem estática.

Correção solicitada à ferramenta: remover todo fundo para alpha real, manter as oito poses e identidade, dar margens às figuras, conservar escala e linha de apoio. A inspeção do canal alpha confirmou fundo transparente.

Preparação do atlas: recorte e posicionamento com escala uniforme de 0,8 (sem reconstrução de membros). Atlas 1536×1024, células 384×512, âncora x=210 e apoio y=460. Hip centers na imagem de origem: [250,625,1000,1395,245,615,1000,1405]; apoio das linhas de origem: 483 e 982. Cortes de coluna: 0,410,768,1152,1536. Esses dados permitem repetir o alinhamento sem inventar anatomia.

Os quadros gerados não são garantia de um ciclo artisticamente perfeito. A avaliação do usuário e os ajustes visuais continuam obrigatórios.

## Prompt exato da correção usada no atlas

Production sprite asset edit. Remove the entire brown/black background, replace it with TRUE ALPHA TRANSPARENCY everywhere outside the eight characters, including between legs, arms and tails. Do not paint black or checkerboard. Keep all eight distinct walking poses and character designs. Make each figure 15% smaller inside its own 384x512 cell so feet and tails never cross cell boundaries or canvas borders. Canvas 1536x1024, 4 columns and 2 rows, eight equal cells. Maintain identical body scale in each cell, hip x=205 within each cell, planted foot baseline y=460 within each cell. Preserve all character details; do not add text, floor, glow, backgrounds, shadows, border, grid or props. Transparent PNG sprite sheet ready for engine.
