#!/usr/bin/env python3
"""Prepare 8 existing JOCA drawings as a registered 4x2 atlas.

No new anatomy is generated, and no frames are duplicated/interpolated.
Depends on Pillow and OpenCV for the art preparation process only; neither
is required for playing the packaged build.
"""
from pathlib import Path
from PIL import Image
import numpy as np
import cv2

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / 'art-source/v0.3.4-frames'
TARGET = ROOT / 'public/assets/joca-walk.png'
FRAME_W, FRAME_H, ANCHOR_X, BASELINE = 540, 500, 270, 450
REFERENCE_HEIGHT = 385
HIP_POSITIONS = [260, 258, 253, 254, 258, 262, 259, 265]

sheet = Image.new('RGBA', (FRAME_W*4, FRAME_H*2))
for index in range(8):
    path = SOURCE / f'joca_walk_{index:02}.png'
    arr = np.asarray(Image.open(path).convert('RGBA')).copy()
    # Erase an isolated crescent artefact beyond the extended right foot in poses 0/4.
    if index in (0, 4):
        arr[295:410, 447:, :] = 0
    alpha = arr[:, :, 3]
    # Remove far-away disconnected debris from frame 1/5 while keeping the
    # original painted pixels of the character unchanged.
    labels_count, labels, stats, _ = cv2.connectedComponentsWithStats((alpha > 8).astype('uint8'), 8)
    largest = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    for component in range(1, labels_count):
        if component != largest and stats[component, cv2.CC_STAT_AREA] > 200:
            arr[labels == component] = 0
    ys, xs = np.where(arr[:, :, 3] > 16)
    top, bottom = int(ys.min()), int(ys.max())
    # Only small uniform size adjustments, preserving the source proportions.
    scale = max(.92, min(1.06, REFERENCE_HEIGHT / max(1, bottom-top)))
    picture = Image.fromarray(arr)
    new_size = (round(FRAME_W*scale), round(FRAME_H*scale))
    scaled = picture.resize(new_size, Image.Resampling.LANCZOS)
    target_hip = 258
    orig_hip = HIP_POSITIONS[index]
    left = round(ANCHOR_X - orig_hip*scale + (target_hip-ANCHOR_X))
    y = round(BASELINE - bottom*scale)
    # Alpha composite keeps soft edges without double-multiplying alpha.
    frame = Image.new('RGBA',(FRAME_W,FRAME_H))
    frame.alpha_composite(scaled,(left,y))
    sheet.alpha_composite(frame,((index%4)*FRAME_W,(index//4)*FRAME_H))
sheet.save(TARGET,optimize=True)
print(f'Prepared {TARGET} ({sheet.width}x{sheet.height})')
