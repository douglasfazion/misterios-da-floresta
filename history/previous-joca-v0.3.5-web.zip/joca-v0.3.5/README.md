# JOCA v0.3.5 — laboratório de caminhada (candidata para avaliação)

Esta é uma **versão jogável**, não uma afirmação de aprovação artística. O escopo permanece exclusivamente caminhar, parar, inverter direção e reiniciar. Não há corrida, salto, ataque, chefes ou novas áreas. Os desenhos preservam o Joca parcialmente humano e lupino da v0.3.4.

## Jogar no Windows — sem instalar nada

1. Extraia **todo o ZIP** em uma pasta.
2. Dê dois cliques em **`JOGAR.html`**, no Chrome ou Edge.
3. Clique na área do jogo para ativar o teclado.
4. Use **A/D** ou as **setas** para andar. Use **R** ou o botão **Reiniciar** para voltar ao começo.

O HTML contém o motor Phaser, atlas e imagens incorporados. É independente da internet. Se o navegador bloquear arquivos locais, execute `INICIAR-WINDOWS.cmd` (Node.js ou Python 3) e abra http://127.0.0.1:8000. Alternativamente: `node server.mjs`.

## Código e execução para desenvolvimento

O código-fonte está dividido em `src/`, e a versão Web servida está em `dist/`.

Com Node.js 22.12+ e npm, e quando for possível obter as dependências:

```sh
npm ci
npm run dev        # interface de desenvolvimento
npm test           # testes unitários Vitest
npm run build      # build Vite + JOGAR.html independente
npm run test:e2e   # requer: npx playwright install chromium
```

O pacote inclui também a alternativa offline que preserva Phaser 3.90.0 e usa apenas TypeScript, Node.js e os arquivos distribuídos:

```sh
npm run build:offline   # tsc/AMD + dist/ + JOGAR.html
npm run test:offline    # 11 testes de regras pelo node:test
```

`build:offline` não faz downloads nem usa Vite, mas precisa ter o comando `tsc` disponível (global ou instalado via npm). O runtime de Phaser 3.90.0 é uma cópia da distribuição de JOCA v0.3.3, localizada em `public/vendor/phaser-runtime.js`, com licença preservada em `docs/PHASER-LICENSE.txt`. **Não atualizamos a engine de forma silenciosa.**

### Estrutura

- `src/config.ts`: versão, velocidade, passo fixo, escala, pontos de ancoragem.
- `src/player.ts`: movimento independente de Phaser e deterministicamente testável.
- `src/WalkScene.ts`: ciclo de atualização fixo, integração e estado de QA.
- `src/input.ts`: teclado, foco e limpeza de teclas.
- `src/animation.ts`: exibição das poses desenhadas a partir da distância real.
- `src/camera.ts`: acompanhamento e limites da câmera.
- `src/environment.ts`: cenário modular provisório recuperado.
- `src/assets.ts`: recursos externos ou incorporados para o HTML único.
- `public/assets/joca-walk.png`: atlas registrado de 8 desenhos, 4×2, 540×500 px por célula.
- `art-source/v0.3.4-frames/`: os oito quadros originais da v0.3.4.
- `scripts/prepare_walk.py`: preparação reproduzível do atlas; requer Python + Pillow + NumPy + OpenCV apenas para processamento de arte.
- `scripts/build-offline.mjs`: alternativa de compilação sem dependências Web remotas.
- `tests/`: testes unitários e de navegador.
- `history/`: arquivos anteriores preservados para comparação/recuperação, **não** como versões aprovadas.

## O que avaliar

Caminhe da esquerda para a direita por alguns segundos, solte a tecla e inverta a direção. Observe se **as pernas realmente alternam**, se o personagem mantém a aparência e se a velocidade/ritmo parecem naturais.

### Limitações honestas

Os **oito desenhos herdados** da v0.3.4 ainda têm duas metades do ciclo muito parecidas; o atlas elimina fragmentos isolados, estabiliza escala e apoio, mas **não cria poses inéditas da perna oposta**. Por isso o aspecto artístico de uma passada bilateral perfeita **não está validado**. Não foi inventada anatomia nova ou substituída a identidade do personagem. O estado parado usa a pose 2/8, e a transição pode ser refinada depois da sua avaliação. A câmera e o chão são provisórios. Nenhuma física vertical foi adicionada.

Veja `docs/CHANGELOG.md`, `docs/QA.md`, `docs/ARTE.md` e `docs/DECISOES.md`.
