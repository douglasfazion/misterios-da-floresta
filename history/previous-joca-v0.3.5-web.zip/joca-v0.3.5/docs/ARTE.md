# JOCA 0.3.5 — preparação da animação

Fonte: oito PNGs de `art-source/v0.3.4-frames`, extraídos do ZIP de JOCA v0.3.4. Cada pose já é um desenho com pernas e braços em uma configuração diferente; **não** é uma fotografia ou uma imagem única deformada.

`python scripts/prepare_walk.py` normaliza pequenas variações de tamanho com redimensionamento proporcional (altura de personagem em torno de 385 px), alinha o piso visual em y=450, mantém a referência horizontal da bacia, remove pedaços isolados detectados em duas poses e produz `public/assets/joca-walk.png` em 4 colunas × 2 linhas. Células: 540 × 500 px, transparência RGBA, pés próximos da linha de apoio.

Dependências opcionais de geração da arte: Pillow, NumPy e OpenCV (`pip install pillow numpy opencv-python`). Elas **não** são requeridas para jogar; o atlas final já está no ZIP.

A reprodução em Phaser escolhe o quadro pelo deslocamento horizontal real da entidade, dividindo uma passada em oito posições. O parâmetro `MOVE.stride` sincroniza distância e animação. A colisão lógica não acompanha alterações visuais do sprite.

**Aviso artístico:** a segunda metade do ciclo herdado é semelhante à primeira. As poses não mostram necessariamente um passo completo com alternância convincente de duas pernas. Não gerei desenhos inventados para a perna oposta nesta revisão: isso exigirá nova produção artística com referência preservada e avaliação do usuário. O atlas preparado é o asset real integrado nesta build.
