# JOCA — decisões e pendências, v0.3.5

## Aprovadas pelo usuário

- Continuar desenvolvimento real do JOCA em pequenas iterações.
- Tecnologia TypeScript + Phaser, sem mudar engine silenciosamente.
- Escopo v0.3.5: **somente caminhada**, preservando o projeto existente; não começar salto/ataques.
- Entregar apenas um ZIP versionado e não publicar em um Site.
- Preservar o Joca parcialmente humano e lupino, com desenhos da referência existente.

## Recuperação

- v0.3.3: TypeScript/Phaser estruturados, testes e build Web independente.
- v0.3.4: Canvas simples, oito quadros PNG de Joca e parâmetros de movimento.
- v0.3.5 aproveita a estrutura da v0.3.3 e o material visual da v0.3.4.
- Os dois ZIPs originais seguem arquivados em `history/`, junto com a v0.3.2 original previamente preservada. **Nenhuma dessas versões foi declarada aprovada artisticamente.**

## Parâmetros desta candidata

- Jogo 1280×720; laboratório horizontal com largura 4200 e piso y=582.
- Velocidade-alvo 210 px/s; resposta 13; stride de 168 px; passo fixo de 1/120 s.
- Atlas 2160×1000, oito quadros de 540×500, origem na bacia x=258 e apoio y=450.
- Sem física vertical ou novos recursos de gameplay nesta iteração.

## Pendente

- Teste do usuário quanto à alternância de pernas, apoio do pé, postura e transição parado/caminhando.
- Se a animação for reprovada, continuar corrigindo a **mesma iteração**, inclusive eventualmente criando novas poses realmente bilaterais da mesma identidade visual.
- Depois da aprovação, propor — não iniciar automaticamente — o próximo passo do metroidvania.
