# JOCA v0.3.5 — 20/10/2026 — candidata para avaliação

## Entregue

- Recuperada a arquitetura Phaser 3.90.0 + TypeScript da v0.3.3; **nenhuma reescrita por engine diferente**.
- Recuperadas as 8 poses individuais de Joca da v0.3.4; atlas de 4×2 preparado com alpha, remoção de fragmentos desconectados e registro de escala/linha de apoio.
- Mantida a sensação geral de movimento v0.3.4: alvo de 210 px/s, suavização exponencial, ciclo de 168 px. Passo lógico fixo 120 Hz, independente de FPS da tela.
- Enquadramento e lado do personagem seguem o deslocamento real; a pose só avança com distância real. Repouso usa pose mais neutra do conjunto (2/8).
- Correção de inversão de direção: Joca só vira ao realmente começar a se deslocar no outro sentido.
- Revisados foco/perda de foco, reinício, limites, câmera, carregamento e overlay de pose/velocidade.
- Distribuição Web em `dist/`, versão sem instalação `JOGAR.html`, fontes, assets, testes, scripts e backups da v0.3.3/v0.3.4.
- Build offline reproduzível a partir das fontes TypeScript e Phaser 3.90.0 empacotado, pois a instalação npm não estava disponível no ambiente de produção desta entrega.

## Limitações e riscos

- As poses desenhadas continuam **sem dois ciclos anatomicamente independentes para cada perna**; os pares 0/4, 1/5, 2/6, 3/7 são semelhantes. Não declarar caminhada artisticamente aprovada.
- Animar uma pose após outra garante movimento da perna visível, mas não garante apoio de pé sem escorregamento; avaliação humana ainda é obrigatória.
- Ao parar ocorre troca para a pose de repouso; transição visual ainda pode ser ajustada.
- Solo e fundo seguem provisórios, sem colisão vertical/plataformas, inimigos, salto ou combate.
- O caminho npm/Vite foi mantido, mas neste ambiente a instalação npm não concluiu; foram executados `tsc`, build offline, testes Node e verificação real em Chromium via HTML incorporado. Testes Playwright npm não foram executados como suíte `npx playwright test`.
- Não houve validação no hardware/navegador específico do usuário.
