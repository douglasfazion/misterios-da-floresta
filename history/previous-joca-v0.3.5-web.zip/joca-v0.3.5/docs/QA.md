# QA — JOCA v0.3.5

## Efetivamente executado neste ambiente

1. `tsc --noEmit`: verificação de tipos TypeScript passou.
2. `node scripts/build-offline.mjs`: compilou módulos TypeScript AMD, produziu `dist/index.html`, `dist/app.js`, runtime Phaser e `JOGAR.html` com imagens e scripts incorporados; passou.
3. `node scripts/test-offline.mjs`: **11 de 11 testes passaram** usando o `node:test`, incluindo limite em ambos os sentidos, aceleração, desaceleração, virada, parada, fase baseada em deslocamento real, determinismo, perda de foco e passo de tempo inválido.
4. Chromium headless 144: renderizou a mesma saída HTML incorporada de `JOGAR.html` usando `page.set_content`, sem erros JavaScript. **13 de 13 verificações de integração passaram**: carregamento/versão/textura, repouso, ida à direita, velocidade, pelo menos 6 quadros distintos exibidos, câmera, parada e ausência de deriva, direção à esquerda, blur, recuperação de foco, reset e ausência de exceções.
5. Inspeção visual da captura do jogo integrado e atlas gerado.

## Não executado / não garantido

- A navegação direta `file://` ou `http://127.0.0.1` pelo Chromium automatizado deste ambiente foi bloqueada por política local (erro `ERR_BLOCKED_BY_ADMINISTRATOR`). Por isso a verificação de integração usou o **conteúdo integral** do HTML incorporado, injetado em `about:blank`, e não equivalia a abrir o arquivo pelo sistema operacional do usuário.
- `npm ci` não concluiu porque o acesso ao registro de pacotes não estava disponível. Portanto, a suíte Vitest e a suíte Playwright via npm foram atualizadas no projeto, mas **não** são contabilizadas como executadas nesta entrega.
- Windows, Chrome/Edge do computador do usuário e sensação visual da caminhada: aguardam validação.
- Testes funcionais mostram que quadros variam; **não comprovam automaticamente** peso, contato perfeito dos pés ou alternância bilateral convincente. Isso permanece pendente de avaliação.

## Como reproduzir

Sem dependências de npm: `node scripts/test-offline.mjs`, `node scripts/build-offline.mjs` (ambos exigem `tsc`), `node server.mjs` e Chrome/Edge.

Com dependências disponíveis: `npm ci`, `npm test`, `npm run build`, `npm run test:e2e` (após `npx playwright install chromium`).
