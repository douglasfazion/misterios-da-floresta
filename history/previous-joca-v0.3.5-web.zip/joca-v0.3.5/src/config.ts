// All tunable values for this isolated, horizontal walking laboratory.
export const VERSION='0.3.5' as const;
export const WORLD={width:4200,height:720,ground:582,minX:86,maxX:4100,startX:180} as const;
export const MOVE={
 speed:210,
 response:13,              // v0.3.4 acceleration feel, exponential smoothing
 stopThreshold:0.4,        // avoid perpetual micromovement on release
 stride:168,               // world pixels per eight-pose cycle
 fixedStep:1/120,
} as const;
export const ART={
 height:300,frameWidth:540,frameHeight:500,frames:8,footY:450,anchorX:258,
 idleFrame:1,
} as const;
