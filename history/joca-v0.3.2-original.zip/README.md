# JOCA v0.3.2 — Laboratório de caminhada

Teste **isolado** de caminhada: sem corrida, ataque, pulo ou inimigos. Cenário da Mata Amaldiçoada preservado como fundo.

## Mudanças

- Substituição do conjunto de quadros praticamente estáticos por uma **sequência gerada com pernas articuladas**, 16 quadros.
- A fase da caminhada depende da distância percorrida, sem descontinuidade temporal no reinício.
- Posição vertical do tronco e do personagem mantida constante.
- Apenas controles esquerda/direita e reiniciar.

## Controles

- A / D ou setas: caminhar
- R: reiniciar

## Observação artística importante

Este é um teste **experimental** de articulação e alinhamento: as pernas foram reconstruídas a partir de texturas da arte aprovada; não são quadros totalmente redesenhados por um animador. A estética/anatomia das pernas ainda pode exigir refinamento manual. O objetivo aqui é comprovar alternância real e ausência de degrau vertical, sem alterar outros sistemas.

## Publicação

Descompacte e envie o conteúdo da pasta `joca-v0.3.2` para o repositório GitHub Pages. Por ser estático, basta ativar Pages a partir do diretório raiz ou usar seu workflow de publicação estática.
